<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="public/css/products.css">
    <link rel="icon" type="image/svg+xml" href="public/images/faviconArt.png">
    <title>Collares</title>
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container_title_categoria">
        <h2>Variedades de Collares</h2> 
    </div>
    <div class="container_main_products">
        <div class="container-items">
            <?php
                include 'app/config.php'; 
                $stmt = $pdo->query("SELECT * FROM products WHERE category = 'Collares'");
                $stmt->execute();
                $products = $stmt->fetchAll();

                foreach ($products as $product): ?>
                    <div class="item">
                        <figure>
                            <img src="data:image/jpeg;base64,<?php echo base64_encode($product['imageProduct']); ?>" alt="<?php echo $product['nameProduct']; ?>" />
                        </figure>
                        <div class="stars">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-regular fa-star"></i>
                        </div>
                        <div class="info-product">
                            <h2><?php echo $product['nameProduct']; ?></h2>
                            <p class="price">$<?php echo $product['priceProduct']; ?></p>
                            <button class="btn-add-cart" data-name="<?php echo $product['nameProduct']; ?>" data-price="<?php echo $product['priceProduct']; ?>">Añadir al carrito</button>
                        </div>
                    </div>
                <?php endforeach; ?>
        </div>
    </div>

    <?php include 'footer.php'; ?>
    <script src="cart.js"></script>
</body>
</html>
s