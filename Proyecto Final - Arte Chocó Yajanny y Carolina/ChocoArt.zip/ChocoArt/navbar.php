<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="public/css/navbar.css">
    <link rel="stylesheet" href="public/css/products.css">
    <title>Barra de Navegación</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="icon" type="image/svg+xml" href="public/images/faviconArt.png">
</head>

<body>
    <header>
        <div class="logoArte">
            <img src="public/images/logoArt.png" alt="img">
        </div>
        <input type="checkbox" id="nav_check" hidden>

        <nav>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li>
                    <a href="#"><i class="fas fa-shopping-bag"></i> Categorías</a>
                    <ul class="menu_vertical">
                        <li><a href="arete.php">Arete</a></li>
                        <li><a href="collar.php">Collar</a></li>
                        <li><a href="bolso.php">Bolso</a></li>
                        <li><a href="manillas.php">Manillas</a></li>
                    </ul>
                </li>
                <li><a href="about.php">Acerca de</a></li>


                <li class="container-icon">
                    <div class="container-cart-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="icon-cart">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007zM8.625 10.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm7.5 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
                        </svg>
                        <div class="count-products">
                            <span id="contador-productos">0</span>
                        </div>
                    </div>
                    <div class="container-cart-products hidden-cart">
                        <div class="row-product hidden"></div>
                        <div class="cart-total hidden">
                            <h3>Total:</h3>
                            <span class="total-pagar">$0</span>
                        </div>
                        <p class="cart-empty">El carrito está vacío</p>
                    </div>
                </li>

                <?php if (isset($_SESSION['SESSION_EMAIL'])) : ?>
                <li><a href="#"><i class="fa-solid fa-user"></i> <?= htmlspecialchars($_SESSION['SESSION_NAME']) ?></a>
                </li>
                <li><a href="#" id="logout-btn">Cerrar sesión</a></li>
                <?php else : ?>
                <li><a class="nav_login_in" href="signIn.php">Iniciar sesión</a></li>
                <li><a class="nav_login_up" href="signUp.php">Registrarse</a></li>
                <?php endif; ?>
            </ul>
        </nav>

        <label for="nav_check" class="hamburger">
            <i class="fa-solid fa-bars" style="color: #ffffff;"></i>
        </label>
    </header>

    <script>
    document.getElementById('logout-btn').addEventListener('click', function(e) {
        e.preventDefault();
        Swal.fire({
            title: '¿Estás seguro?',
            text: "¿Quieres cerrar sesión?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, cerrar sesión'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'logout.php';
            }
        })
    });
    </script>
</body>

</html>