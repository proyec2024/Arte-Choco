<?php
    include 'app/config.php';
    //Mostrar todos los usuarios
    $stmt = $pdo->query("SELECT * FROM register");
    $stmt->execute();
    $users = $stmt->fetchAll();

    //Añadir un nuevo usuario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['submit'])) {
        // Añadir nuevo usuario
        $name = trim($_POST['name']);
        $lastName = trim($_POST['lastName']);
        $identifi = trim($_POST['identifi']);
        $email = trim($_POST['email']);
        $password = md5(trim($_POST['password']));

        try {
            $stmt = $pdo->prepare("SELECT * FROM register WHERE email = :email OR identifi = :identifi");
            $stmt->execute(['email' => $email, 'identifi' => $identifi]);
            if ($stmt->rowCount() > 0) {
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($row['email'] === $email) {
                    $msg = "{$email} - Este correo ya ha sido registrado.";
                } else {
                    $msg = "{$identifi} - Esta identificación ya ha sido registrada.";
                }
            } else {
                $stmt = $pdo->prepare("INSERT INTO register (name, lastName, identifi, email, password) VALUES (:name, :lastName, :identifi, :email, :password)");
                $result = $stmt->execute(['name' => $name, 'lastName' => $lastName, 'identifi' => $identifi, 'email' => $email, 'password' => $password]);

                if ($result) {
                    echo '<script>alert("Usuario registrado exitosamente");</script>';
                    header("Location: {$_SERVER['PHP_SELF']}");
                    exit();
                } else {
                    $msg = "Algo salió mal.";
                }
            }
        } catch (PDOException $e) {
            $msg = "Error en la base de datos: " . $e->getMessage();
        }
    } elseif (isset($_POST['edit'])) {
        // Editar usuario
        $id = $_POST['id'];
        $name = trim($_POST['name']);
        $lastName = trim($_POST['lastName']);
        $identifi = trim($_POST['identifi']);
        $email = trim($_POST['email']);
        $password = md5(trim($_POST['password']));

        try {
            $stmt = $pdo->prepare("UPDATE register SET name = :name, lastName = :lastName, identifi = :identifi, email = :email, password = :password WHERE id = :id");
            $stmt->execute(['name' => $name, 'lastName' => $lastName, 'identifi' => $identifi, 'email' => $email, 'password' => $password, 'id' => $id]);
            header("Location: {$_SERVER['PHP_SELF']}");
            exit();
        } catch (PDOException $e) {
            $msg = "Error en la base de datos: " . $e->getMessage();
        }
    }
} elseif ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['delete_id'])) {
    // Eliminar usuario
    $id = $_GET['delete_id'];

    try {
        $stmt = $pdo->prepare("DELETE FROM register WHERE id = :id");
        $stmt->execute(['id' => $id]);
        header("Location: {$_SERVER['PHP_SELF']}");
        exit();
    } catch (PDOException $e) {
        $msg = "Error en la base de datos: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios</title>
</head>
<body>
    <header>
        <h1>Usuarios</h1>
        <?php require_once('menu.php'); ?>
    </header>
        <div class="container-fluid">
            <div class="row">
                <form action="" method="post">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">Añadir Nuevo Usuario</button>
                </form>
            <table class="table">
                <thead>
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Apellido</th>
                    <th scope="col">Email</th>
                    <th scope="col">Identificacion</th>
                    <th scope="col">contraseña</th>
                    <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user) : ?>
                    <tr>
                    <th scope="row"><?php echo $user['id']; ?></th>
                        <td><?php echo $user['name']; ?></td>
                        <td><?php echo $user['lastName']; ?></td>
                        <td><?php echo $user['email']; ?></td>
                        <td><?php echo $user['identifi']; ?></td>
                        <td><?php echo $user['password']; ?></td>
                        <td>
                        <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $user['id']; ?>"><i class="bi bi-pencil-square"></i> Editar</button>
                        <a href="?delete_id=<?php echo $user['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar este usuario?');"><i class="bi bi-trash"></i> Eliminar</a>
                            <!-- <button type="button" class="btn btn-warning"><i class="bi bi-pencil-square"></i> Editar</button> -->
                            <!-- <button type="button" class="btn btn-danger"><i class="bi bi-trash"></i>Eliminar</button> -->
                        </td>
                    </tr>
                    <!-- Modal para editar usuario -->
                    <div class="modal fade" id="editModal<?php echo $user['id']; ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo $user['id']; ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="editModalLabel<?php echo $user['id']; ?>">Editar usuario</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="" method="POST">
                                                <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                                                <div class="mb-3">
                                                    <input type="text" name="name" value="<?php echo $user['name']; ?>" class="form-control" required>
                                                </div>
                                                <div class="mb-3">
                                                    <input type="text" name="lastName" value="<?php echo $user['lastName']; ?>" class="form-control" required>
                                                </div>
                                                <div class="mb-3">
                                                    <input type="text" name="identifi" value="<?php echo $user['identifi']; ?>" class="form-control" required>
                                                </div>
                                                <div class="mb-3">
                                                    <input type="email" name="email" value="<?php echo $user['email']; ?>" class="form-control" required>
                                                </div>
                                                <div class="mb-3">
                                                    <input type="password" name="password" class="form-control" required>
                                                </div>
                                                <button type="submit" name="edit" class="btn btn-primary">Guardar Cambios</button>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    <?php endforeach; ?>
                </tbody>
                </table>
            </div>
        </div>

             <!-- Modal para añadir usuario -->
        <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Añadir un nuevo usuario</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="" method="POST" autocomplete="off">
                            <div class="mb-3">
                                <input type="text" name="name" minlength="4" class="form-control" required placeholder="Nombre">
                            </div>
                            <div class="mb-3">
                                <input type="text" name="lastName" class="form-control" required placeholder="Apellido">
                            </div>
                            <div class="mb-3">
                                <input type="text" name="identifi" class="form-control" required placeholder="Identificación">
                            </div>
                            <div class="mb-3">
                                <input type="email" name="email" class="form-control" required placeholder="Correo">
                            </div>
                            <div class="mb-3">
                                <input type="password" name="password" minlength="4" class="form-control" required placeholder="Contraseña">
                            </div>
                            <button type="submit" name="submit" class="btn btn-primary">Guardar Usuario</button>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>

        
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>