<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="public/css/about.css" >
    <link rel="icon" type="image/svg+xml" href="public/images/faviconArt.png">
    <title>About</title>
</head>

<body>
<?php include 'navbar.php'; ?>

    <h1 class="title_about_main">identidad cultural</h1>

    <div class="container_about">
        <div class="container_about_first">
            <div class="container_about_image_first">
                <img src="public/images/malecon.jpg" alt="">
            </div>
            <div class="container_about_text_first">
                <h3 class="title_about_first">Reseña del Chocó</h3>
                <p>El Chocó es uno de los 32 departamentos de Colombia, localizado en el noroeste del país, en la región
                    del Pacífico colombiano. Comprende las selvas del Darién y las cuencas de los ríos Atrato y San
                    Juan. Su capital es la ciudad de Quibdó.
                    <br><br> Es el único departamento de Colombia con costas en los océanos Pacífico y Atlántico. Es
                    igualmente el único departamento limítrofe con Panamá. En ella se encuentra la ecorregión que
                    probablemente tenga la mayor pluviosidad del planeta. A grandes líneas comprende la mitad del
                    litoral nacional en el océano Pacífico. El Chocó colombiano es rico en biodiversidad y cultura
                    influenciada por Emberá, Waunana, españoles y africanos. A pesar de mejoras, persisten la pobreza y
                    la violencia. Su importancia ecológica destaca la necesidad de conservación y desarrollo sostenible.
                </p>
            </div>
        </div>

        <div class="container_about_second">

            <div class="container_about_text_second">
                <h3 class="title_about_second">Cultura y tradiciones</h3>
                <p>El Chocó, en la costa del Pacífico de Colombia, es rico en cultura. Afrocolombianos e indígenas
                    Emberá y Wounaan conforman su población. Destacan el currulao, la artesanía como las mochilas
                    tejidas, y la cocina con ingredientes locales como pescado y coco. Las festividades religiosas, como
                    la Semana Santa y San Pacho, son importantes. Su cosmovisión se centra en la conexión con la
                    naturaleza y la espiritualidad. La cultura chocoana fusiona tradiciones afrocolombianas e indígenas
                    en música, danza, arte, cocina y festividades, reflejando su profunda conexión con el entorno
                    natural y su herencia cultural.</p>
            </div>

            <div class="container_about_image_second">
                <img src="public/images/cultura.jpg" alt="">
            </div>

        </div>



        <div class="container_about_third">
            <div class="container_about_image_third">
                <img src="public/images/artesanias.jpg" alt="">
            </div>
            <div class="container_about_text_third">
                <h3 class="title_about_third">Artesanias Chocoanas</h3>
                <p>La artesanía en el Chocó es una expresión viva de su cultura arraigada. Los hábiles artesanos
                    chocoanos utilizan materiales naturales y técnicas tradicionales para crear piezas de joyería en oro
                    y platino, así como obras de cestería tejidas con fibras como el cañaflecha, resaltando sus diseños
                    coloridos y patrones geométricos. Además, la madera tallada da vida a esculturas y objetos
                    decorativos que reflejan la profunda conexión espiritual y la relación del Chocó con su entorno
                    natural, adornados con detalles intrincados que cuentan historias de la región.</p>
            </div>
        </div>
    </div>
    <?php include 'footer.php'; ?>

</body>

</html>