<?php
// session_start();

// Conexión a la base de datos
include 'app/config.php'; // Asegúrate de que el archivo config.php está en la misma ruta o ajusta la ruta correctamente
$msg = "";
$registration_success = false; // Inicializar la bandera de éxito de registro

if (isset($_POST['submit'])) {
    $name = trim($_POST['name']);
    $lastName = trim($_POST['lastName']);
    $identifi = trim($_POST['identifi']);
    $email = trim($_POST['email']);
    $password = md5(trim($_POST['password'])); // Usa una función de hash más segura como password_hash en producción

    // Validaciones de los campos
    if (empty($name) || empty($lastName) || empty($identifi) || empty($email) || empty($password)) {
        $msg = "Todos los campos son obligatorios.";
    } elseif (!is_numeric($identifi) || strlen($identifi) != 10) {
        $msg = "La identificación debe ser numérica y tener exactamente 10 dígitos.";
    } else {
        try {
            // Comprobar si el correo o la identificación ya existen
            $stmt = $pdo->prepare("SELECT * FROM register WHERE email = :email OR identifi = :identifi");
            $stmt->execute(['email' => $email, 'identifi' => $identifi]);
            if ($stmt->rowCount() > 0) {
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($row['email'] === $email) {
                    $msg = "{$email} - Este correo ya ha sido registrado.";
                } else {
                    $msg = "{$identifi} - Esta identificación ya ha sido registrada.";
                }
            } else {
                // Insertar el nuevo registro
                $stmt = $pdo->prepare("INSERT INTO register (name, lastName, identifi, email, password) VALUES (:name, :lastName, :identifi, :email, :password)");
                $result = $stmt->execute(['name' => $name, 'lastName' => $lastName, 'identifi' => $identifi, 'email' => $email, 'password' => $password]);

                if ($result) {
                    $registration_success = true;
                } else {
                    $msg = "Algo salió mal.";
                }
            }
        } catch (PDOException $e) {
            $msg = "Error en la base de datos: " . $e->getMessage();
        }
    } 
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="public/css/signUp.css">
    <link rel="icon" type="image/svg+xml" href="public/images/faviconArt.png">
    <title>Registro</title>
    <!-- Incluir SweetAlert y jQuery -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <?php include 'navbar.php'; ?>
    <main class="modo-registroup">
        <div class="cajaup">
            <div class="caja-internaup">
                <div class="contenedor-formulariosup">
                    <form id="registrationForm" action="" method="POST" autocomplete="off"
                        class="formulario-registroup">
                        <!-- <div class="logoup">
                        <img src="public/images/logoArtechoco.png" alt="logo">
                        <h4>Arte Chocó</h4>
                    </div> -->
                        <div class="encabezadoup">
                            <h2>Regístrate</h2>
                            <h6>¿Ya tienes una cuenta?</h6>
                            <a href="signIn.php" class="cambiarup">Iniciar sesión</a>
                        </div>
                        <div class="formulario-actualup">
                            <div class="campo-entradaup">
                                <input type="text" name="name" minlength="4" class="campo-textoup" autocomplete="off"
                                    required placeholder="Nombre"
                                    value="<?php if (isset($_POST['submit'])) { echo htmlspecialchars($name); } ?>">
                            </div>
                            <div class="campo-entradaup">
                                <input type="text" name="lastName" class="campo-textoup" autocomplete="off" required
                                    placeholder="Apellido"
                                    value="<?php if (isset($_POST['submit'])) { echo htmlspecialchars($lastName); } ?>">
                            </div>
                            <div class="campo-entradaup">
                                <input type="text" name="identifi" class="campo-textoup" autocomplete="off" required
                                    placeholder="Identificación"
                                    value="<?php if (isset($_POST['submit'])) { echo htmlspecialchars($identifi); } ?>">
                            </div>
                            <div class="campo-entradaup">
                                <input type="email" name="email" class="campo-textoup" autocomplete="off" required
                                    placeholder="Correo"
                                    value="<?php if (isset($_POST['submit'])) { echo htmlspecialchars($email); } ?>">
                            </div>
                            <div class="campo-entradaup">
                                <input type="password" name="password" minlength="4" class="campo-textoup"
                                    autocomplete="off" required placeholder="Contraseña">
                            </div>
                            <input type="submit" name="submit" value="Registrarse" class="boton-registroup">
                            <!-- <p class="textoup"> 
                            Al registrarme, acepto los
                            <a href="#">Términos de Servicio</a> y
                            <a href="#">Política de Privacidad</a>
                        </p> -->
                        </div>
                    </form>
                </div>
                <div class="carruselup"> 
                    <div class="contenedor-imagenesup">
                        <img src="public/images/imagen3.jpg" class="imagenup img-1up mostrarup" alt="">
                        <img src="" class="imagenup img-2up" alt="">
                        <img src="" class="imagenup img-3up" alt="">
                    </div>
                    <div class="deslizador-textoup">
                        <div class="contenedor-textoup">
                            <div class="grupo-textoup">

                            </div>
                        </div>
                        <div class="puntosup">
                            <span class="activoup" data-value="1"></span>
                            <span data-value="2"></span>
                            <span data-value="3"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script>
    $(document).ready(function() {
        <?php if (!empty($msg)): ?>
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: '<?php echo $msg; ?>'
        });
        <?php endif; ?>

        <?php if ($registration_success): ?>
        $('#registrationForm')[0].reset();
        Swal.fire({
            icon: 'success',
            title: 'Registro exitoso',
            text: '¡Tu registro ha sido exitoso! Puedes iniciar sesión ahora.',
        }).then(function() {
            window.location.href = "signIn.php";
        });
        <?php endif; ?>
    });

    $('.identifi').on('input', function() {
        this.value = this.value.replace(/\D/g, '').slice(0, 10);
    });
    </script>

</body>

</html>