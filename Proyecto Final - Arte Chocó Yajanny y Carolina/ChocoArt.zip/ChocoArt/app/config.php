<?php
// Datos de conexión a la base de datos
$host = 'localhost'; // Servidor de la base de datos
$port = '3306'; // Puerto de la base de datos (el valor por defecto para MySQL es 3306)
$dbname = 'sistemaventa'; // Nombre de la base de datos
$username = 'root'; // Nombre de usuario de la base de datos
$password = ''; // Contraseña del usuario de la base de datos

// Construir la cadena DSN (Data Source Name)
$dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8";

try {
    // Crear una nueva instancia de PDO
    $pdo = new PDO($dsn, $username, $password);
    // Establecer el modo de error de PDO a excepción
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Comentado para evitar salidas innecesarias
    // echo "Conexión exitosa a la base de datos";
} catch (PDOException $e) {
    // Mostrar un mensaje de error si la conexión falla
    echo "Error de conexión a la base de datos: " . $e->getMessage();
}
?>



