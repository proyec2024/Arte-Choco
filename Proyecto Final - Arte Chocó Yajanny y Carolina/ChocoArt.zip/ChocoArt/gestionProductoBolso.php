<?php 
        //tabla: products
        //campos: id,nameProduct,priceProduct,imageProduct
        include 'app/config.php';
        //Mostrar todos los producto
        $stmt = $pdo->query("SELECT * FROM products WHERE category = 'Bolsos'");
        $stmt->execute();
        $products = $stmt->fetchAll();
    
        //Añadir un nuevo producto
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (isset($_POST['submit'])) {
            // Añadir nuevo producto
            $nameProduct = trim($_POST['nameProduct']);
            $priceProduct = trim($_POST['priceProduct']);
            $imageProduct = file_get_contents($_FILES['imageProduct']['tmp_name']);
    
            try {
                    $stmt = $pdo->prepare("INSERT INTO products (nameProduct, priceProduct, imageProduct, category) VALUES (:nameProduct, :priceProduct, :imageProduct, 'Bolsos')");
                    $result = $stmt->execute(['nameProduct' => $nameProduct, 'priceProduct' => $priceProduct, 'imageProduct' => $imageProduct]);
    
                    if ($result) {
                        echo '<script>alert("Bolsos nuevos registrado exitosamente");</script>';
                        header("Location: {$_SERVER['PHP_SELF']}");
                        exit();
                    } else {
                        $msg = "Algo salió mal.";
                }
            } catch (PDOException $e) {
                $msg = "Error en la base de datos: " . $e->getMessage();
            }
        } elseif (isset($_POST['edit'])) {
            // Editar producto
            $id = $_POST['id'];
            $nameProduct = trim($_POST['nameProduct']);
            $priceProduct = trim($_POST['priceProduct']);
            $imageProduct = file_get_contents($_FILES['imageProduct']['tmp_name']);

    
            try {
                $stmt = $pdo->prepare("UPDATE products SET nameProduct = :nameProduct, priceProduct = :priceProduct, imageProduct = :imageProduct WHERE id = :id");
                $stmt->execute(['nameProduct' => $nameProduct, 'priceProduct' => $priceProduct, 'imageProduct' => $imageProduct, 'id' => $id]);
                header("Location: {$_SERVER['PHP_SELF']}");
                exit();
            } catch (PDOException $e) {
                $msg = "Error en la base de datos: " . $e->getMessage();
            }
        }
    } elseif ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['delete_id'])) {
        // Eliminar producto
        $id = $_GET['delete_id'];
    
        try {
            $stmt = $pdo->prepare("DELETE FROM products WHERE id = :id");
            $stmt->execute(['id' => $id]);
            header("Location: {$_SERVER['PHP_SELF']}");
            exit();
        } catch (PDOException $e) {
            $msg = "Error en la base de datos: " . $e->getMessage();
        }
    }
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Gestor de Productos - Bolsos</title>
</head>

<body>
    <header>
        <h1>Gestor de Productos - Bolsos</h1>
        <?php include 'menu.php'; ?>
    </header>

    <div class="container-fluid">
            <div class="row">
                <form action="" method="post">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModal">Añadir Nuevo Producto</button>
                </form>
            <table class="table">
                <thead>
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nombre del Producto</th>
                    <th scope="col">Precio</th>
                    <th scope="col">Imagen</th>
                    <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $product) : ?>
                    <tr>
                    <th scope="row"><?php echo $product['id']; ?></th>
                        <td><?php echo $product['nameProduct']; ?></td>
                        <td><?php echo $product['priceProduct']; ?></td>
                        <td><?php if($product['imageProduct']):?>
                            <img style="width: 100px; height: 100px" src="data:image/jpeg;base64,<?php echo base64_encode($product['imageProduct']); ?>" />
                        <?php endif; ?>
                        </td>
                        <td>
                        <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $product['id']; ?>"><i class="bi bi-pencil-square"></i> Editar Bolso</button>
                        <a href="?delete_id=<?php echo $product['id']; ?>" class="btn btn-danger" onclick="return confirm('¿Estás seguro de que deseas eliminar este producto?');"><i class="bi bi-trash"></i> Eliminar</a>
                            <!-- <button type="button" class="btn btn-warning"><i class="bi bi-pencil-square"></i> Editar</button> -->
                            <!-- <button type="button" class="btn btn-danger"><i class="bi bi-trash"></i>Eliminar</button> -->
                        </td>
                    </tr>
                    <!-- Modal para editar productos -->
                    <div class="modal fade" id="editModal<?php echo $product['id']; ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo $product['id']; ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="editModalLabel<?php echo $product['id']; ?>">Editar Producto</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="" enctype="multipart/form-data" method="POST">
                                                <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                                                <div class="mb-3">
                                                    <input type="text" name="nameProduct" value="<?php echo $product['nameProduct']; ?>" class="form-control" required>
                                                </div>
                                                <div class="mb-3">
                                                    <input type="number" name="priceProduct" value="<?php echo $product['priceProduct']; ?>" class="form-control" required>
                                                </div>
                                                <div class="mb-3">
                                                    <input type="file" name="imageProduct" accept="image/*" class="form-control" required placeholder="Foto">
                                                </div>
                                                <button type="submit" name="edit" class="btn btn-primary">Guardar Cambios</button>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    <?php endforeach; ?>
                </tbody>
                </table>
            </div>
        </div>

             <!-- Modal para añadir producto -->
        <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Añadir un nuevo Producto</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="" method="POST" autocomplete="off" enctype="multipart/form-data">
                            <div class="mb-3">
                                <input type="text" name="nameProduct" minlength="4" class="form-control" required placeholder="Nombre Producto">
                            </div>
                            <div class="mb-3">
                                <input type="number" name="priceProduct" class="form-control" required placeholder="Precio del producto">
                            </div>
                            <div class="mb-3">
                                <input type="file" name="imageProduct" accept="image/*" class="form-control" required>
                            </div>
                            <button type="submit" name="submit" class="btn btn-primary">Guardar Producto</button>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>


    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>