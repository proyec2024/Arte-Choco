<?php
include 'app/config.php';
$msg = "";
$msg_type = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    session_start();
    $email = trim($_POST['email']);
    $password = md5($_POST['password']);
    
    $sql = "SELECT * FROM register WHERE email = :email AND password = :password";
    $smt = $pdo->prepare($sql);
    $smt->execute(['email' => $email, 'password' => $password]);
    $row = $smt->fetch();

    if ($row) { 
        $_SESSION['SESSION_EMAIL'] = $email;
        $_SESSION['SESSION_NAME'] = $row['name']; // Suponiendo que existe una columna 'name' en la tabla 'register'
        
        // Verificación para el administrador
        if ($email === 'admin@gmail.com' && $_POST['password'] === '0126') {
            echo "<script>
                    window.location.href = 'dashboard.php';
                 </script>";
        } else {
            $msg = "¡Bienvenido!";
            $msg_type = "success";
            echo "<script>
                    window.location.href = 'index.php';
                 </script>";
        }
    } else {
        $msg = "Correo electrónico o contraseña incorrecta.";
        $msg_type = "error";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="public/css/signIn.css">
    <link rel="icon" type="image/svg+xml" href="public/images/faviconArt.png">
    <title>Iniciar Sesión</title>
</head>
<body>
<?php include 'navbar.php'; ?>
<main>
    <div class="caja"> 
        <div class="caja-interna">
            <div class="contenedor-formularios">
                <form action="" method="POST" autocomplete="off" class="formulario-inicio-sesion">
                    <div class="encabezado">
                        <h2>Inicia sesión</h2>
                        <h6>¿Todavía no estás registrado?</h6>
                        <a href="signUp.php" class="alternar">Registrate</a>
                    </div>

                    <div class="formulario-real">
                        <div class="campo-input">
                            <input
                                type="email"
                                name="email"
                                class="campo-texto"
                                autocomplete="off"
                                required
                                placeholder="Correo"
                            />
                        </div>

                        <div class="campo-input">
                            <input
                                type="password"
                                name="password"
                                class="campo-texto"
                                autocomplete="off"
                                required
                                placeholder="Contraseña"
                            />
                        </div>

                        <input type="submit" name="submit" value="Iniciar Sesión" class="boton-iniciar" />
                    </div>
                </form>

                <div class="carruselin"> 
                    <div class="contenedor-imagenesin">
                        <img src="public/images/imagen4.jpg" alt="">
                    </div>
                    <div class="deslizador-textoup">
                        <div class="contenedor-textoin">
                            <div class="grupo-textoin">
                            </div>
                        </div>
                        <div class="puntosin">
                            <span class="activoin" data-value="1"></span>
                            <span data-value="2"></span>
                            <span data-value="3"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
$(document).ready(function () {
    <?php if (!empty($msg)): ?>
        Swal.fire({
            icon: '<?php echo $msg_type; ?>',
            title: 'Alerta',
            text: '<?php echo $msg; ?>'
        });
    <?php endif; ?>
});
</script>

</body>
</html>
