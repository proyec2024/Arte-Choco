

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="public/css/index.css" type="text/css" media="all" />
    <link rel="icon" type="image/svg+xml" href="public/images/faviconArt.png">
    <title>Arte Chocó</title>
</head>

<body>
<?php include 'navbar.php'; ?>

    <div class="container_inicio">
        <div class="container_text">

            <h1 class="text_in"> Explora y admira la artesanía chocoana, hecha con materiales naturales que reflejan la
                identidad y tradición de las comunidades afrodescendientes. ¡Bienvenidos!</h1>
        </div>
    </div>


    <div class="container_categoria">
        <h1>Categorías</h1>
        <div class="categories">
            <div class="categoria">
                <a href="arete.php">
                    <img src="public\images\arete1.jpg" alt="Aretes">
                    <h2>ARETES</h2>
                </a>
            </div>
            <div class="categoria">
                <a href="collar.php">
                    <img src="public\images\arete2.jpg" alt="Collares">
                    <h2>COLLARES</h2>
                </a>
            </div>
            <div class="categoria">
                <a href="bolso.php">
                    <img src="public\images\arte7.jpg" alt="Bolsos">
                    <h2>BOLSOS</h2>
                </a>
            </div>
            <div class="categoria">
                <a href="manillas.php">
                    <img src="public\images\arete4.jpg" alt="Manillas">
                    <h2>MANILLAS</h2>
                </a>
            </div>
        </div>
    </div>



    <div class="container_inicio2">
        <div class="text_ini">
            <h1>ARTESANÍAS CHOCOANAS</h1>
        </div>

        <div class="container_card">

            <div class="container_card1">
                <img src="public\images\arte1.jpg" alt="">
            </div>
            <div class="container_card1">
                <img src="public\images\arte2.jpg" alt="">
            </div>
            <div class="container_card1">
                <img src="public\images\arte3.jpg" alt="">
            </div>
            <div class="container_card1">
                <img src="public\images\arte4.jpg" alt="">
            </div>
            <div class="container_card1">
                <img src="public\images\arte5.jpg" alt="">
            </div>
            <div class="container_card1">
                <img src="public\images\arte6.jpg" alt="">
            </div>

        </div>
    </div>
    <?php include 'footer.php'; ?>
    


</body>

</html>