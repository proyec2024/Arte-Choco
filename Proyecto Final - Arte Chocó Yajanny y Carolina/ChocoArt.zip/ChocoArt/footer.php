<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="public\css\footer.css" type="text/css" media="all" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha384-k6RqeWeci5ZR/Lv4MR0sA0FfDOMix4i3TE1w8V1kZZl7+aRyz2bOWjr5Q4mRbb3U" crossorigin="anonymous">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
   <title>Document</title>
</head>
<body>

<footer class="footer-distributed">

<div class="footer-left">
    <!-- <h3>Arte<span>Chocó</span></h3> -->
    <div class="container_logoFooter">
        <img src="public\images\logoArtechoco.png" alt="">
    </div>

    <p class="footer-links">
        <a href="#">Tradición</a>
        |
        <a href="#">Herencia</a>
        |
        <a href="#">Creatividad</a>
       
    </p>

    <p class="footer-company-name">Copyright © 2024 <strong>Arte Chocó</strong> Todos los derechos reservados.</p>
</div>

<div class="footer-center">
    <div>
    <i class="fas fa-map-marker-alt"></i>


        <p><span>Chocó</span>
            Quibdó</p>
    </div>

    <div>
    <i class="fa-solid fa-phone"></i>
        <p>+57 3117600000</p>
    </div>
    <div>
        <i class="fa fa-envelope"></i>
        <p><a href="#">artechoco@gmail.com</a></p>
    </div>
</div>
<div class="footer-right">
    <p class="footer-company-about">
        <span>Acerca de la empresa</span>
        <strong>Arte Chocó</strong> empresa dedicada a la venta de  artesanías chocoanas auténticas, elaboradas con técnicas tradicionales por artesanos locales.
    </p>
    <div class="footer-icons">
        <a href="https://www.facebook.com/?locale=es_LA" target="_blank"><i class="fa-brands fa-facebook"></i></a>
        <a href="https://www.instagram.com/" target="_blank"><i class="fa-brands fa-instagram"></i></a>
        <a href="https://www.linkedin.com/" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
        <a href="https://x.com/?lang=en" target="_blank"><i class="fa-brands fa-twitter"></i></a>
        <a href="https://www.youtube.com/" target="_blank"><i class="fa-brands fa-youtube"></i></a>
    </div>
</div>
</footer>

   
</body>
</html>