<?php include 'app/config.php'; 
        $stmt = $pdo->query("SELECT * FROM products WHERE category = 'Manillas'" );
        $stmt->execute();
        $products = $stmt->fetchAll(); ?>
<?php include 'navbar.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/svg+xml" href="public/images/faviconArt.png">
    <link rel="stylesheet" href="public/css/products.css">
    <title>Manillas</title>
</head>
<body>
    
<!-- </body>
</html> -->

<div class="container_title_categoria">
<h2>Variedades de Manillas</h2> 
</div>
<div class="container_main_products">
    <div class="container-items">
        <?php

    // while (count($products) < 12) {
    //     $products = array_merge($products, $products);
    // }
    // $products = array_slice($products, 0, 12);

    foreach ($products as $product): ?>
        <div class="item">
            <figure>
                <img src="data:image/jpeg;base64,<?php echo base64_encode($product['imageProduct']); ?>" alt="<?php echo $product['nameProduct']; ?>" />
            </figure>
            <div class="stars">
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-regular fa-star"></i>
            </div>

            <div class="info-product">
                <h2><?php echo $product['nameProduct']; ?></h2>
                <p class="price">$<?php echo $product['priceProduct']; ?></p>
                <button class="btn-add-cart" data-name="<?php echo $product['nameProduct']; ?>" data-price="<?php echo $product['priceProduct']; ?>" >Añadir al carrito</button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include 'footer.php'; ?>
<script src="cart.js"></script>
</body>
</html>